This image doesn't contain Windows source code -- head over to
www.openal.org for the full codebase.
