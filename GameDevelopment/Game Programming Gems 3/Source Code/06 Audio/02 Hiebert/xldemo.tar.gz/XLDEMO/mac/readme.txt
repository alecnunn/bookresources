This image doesn't contain Macintosh source code -- head over to
www.openal.org for the full codebase.
