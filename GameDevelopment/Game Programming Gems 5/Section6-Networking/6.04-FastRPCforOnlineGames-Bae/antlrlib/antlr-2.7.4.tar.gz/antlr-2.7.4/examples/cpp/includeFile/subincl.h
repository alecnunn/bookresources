int z;

