/** Test heterogeneous dynamic typing class */
public class ASTType49 extends antlr.CommonAST {
}
