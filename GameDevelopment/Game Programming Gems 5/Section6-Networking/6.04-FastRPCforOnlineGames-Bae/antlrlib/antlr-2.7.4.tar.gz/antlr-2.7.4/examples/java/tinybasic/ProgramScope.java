package tinybasic;

class ProgramScope extends Scope{

    public ProgramScope(Scope prev){
	super(prev);
    }


}
